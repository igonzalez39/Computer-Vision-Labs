%load image
%   img = imread('03.jpg');
%   fprintf('Load 03.jpg...\n');

%show image
%   figure,imshow(img);

%save image
%   imwrite(img, 'output.jpg');
%   fprintf('Save output.jpg...\n');




%Problem 1
I = imread('01.jpg');
fprintf('Load 01.jpg...\n');

I2 = zeros(size(I, 1), size(I, 2), 3, 'uint8');
for i = 1: size(I, 2)
    for j = 1: size(I, 1)
        x = cosd(45)*(i - 200) + sind(45)*(j - 150) + 200;
        y = -sind(45)*(i - 200) + cosd(45)*(j - 150) + 150;
        
        if(x >= 1 && x <= size(I, 2) && y >= 1 && y <= size(I, 1))
            x = round(x); y = round(y);
            I2(y,x,:) = I(j,i,:);
        end
    end 
end

imshow(I2);
imwrite(I2, 'rotate_0.jpg');
fprintf('Save rotate_0.jpg...\n');




%Problem 2
%I = imread('01.jpg');
%fprintf('Load 01.jpg...\n');
%degree = 45;

%Degrees to Radians & Transformation Matrix
%radian = degree*pi/180;
%R = [+cos(radian) +sin(radian); -sin(radian) +cos(radian)];

%Finds size of image after transformation
%[m,n,p] = size(I);
%D = round( [1 1; 1 n; m 1; m n]*R );
%D = bsxfun(@minus, D, min(D)) + 1;
%rotate = zeros([max(D) p],class(I));

%Maps pixels so no more holes
%for ii = 1:size(rotate,1)
      %for jj = 1:size(rotate,2)
          %source = ([ii jj]-D(1,:))*R.';
              %if all(source >= 1) && all(source <= [m n])
                    %C = ceil(source);
                    %F = floor(source);

                    %area = [...
                        %((C(2)-source(2))*(C(1)-source(1))),...
                        %((source(2)-F(2))*(source(1)-F(1)));
                        %((C(2)-source(2))*(source(1)-F(1))),...
                        %((source(2)-F(2))*(C(1)-source(1)))];

                    %Re-scale/color
                    %cols = bsxfun(@times, area, double(I(F(1):C(1),F(2):C(2),:)));               
                    %rotate(ii,jj,:) = sum(sum(cols),2);

              %end
       %end
%end        

%imshow(rotate);
%imwrite(rotate, 'rotate_1.jpg');
%fprintf('Save rotate_1.jpg...\n');




%Problem 3
%img = im2double(imread('lena_noisy.jpg'));
%fprintf('lena_noisy.jpg...\n');

%patch_size = [3, 3];

%img_median = median_filter(img, patch_size);
%imwrite(img_median, 'median_0.jpg');
%fprintf('Save median_0.jpg...\n');



%Problem 4
%img = im2double(imread('lena_noisy.jpg'));
%fprintf('lena_noisy.jpg...\n');

%patch_size = [5, 5];

%img_median = median_filter(img, patch_size);
%imwrite(img_median, 'median_1.jpg');
%fprintf('Save median_1.jpg...\n');







