%gaussian_filter.m

function output = gaussian_filter(img, hsize, sigma)

    H = fspecial('gaussian', hsize, sigma);
    
    I = zeros(size(img));
    xdistance = floor(size(H,2) / 2);
    ydistance = floor(size(H, 1) / 2);
    
    
    for i = (xdistance + 1): (size(img, 2) - xdistance)
        for j = (ydistance + 1): (size(img, 1) - ydistance)
            x1 = i - xdistance;
            y1 = j - ydistance;
            
            x2 = i + xdistance;
            y2 = j + ydistance;
            
            patch = img(y1:y2, x1:x2);
            patch = patch(:);
            
            H = H(:);
            H = H';
            
            value = H * patch;
            I(i,j) = value;
            
            
        end
    end
    
    output = I;
    
end
