%load image
%   img = imread('03.jpg');
%   fprintf('Load 03.jpg...\n');

%show image
%   figure,imshow(img);

%save image
%   imwrite(img, 'output.jpg');
%   fprintf('Save output.jpg...\n');




%Sobel filter
%img = im2double(imread('lena.jpg'));
%fprintf('lena.jpg...\n');

%H = [1, 2, 1; 0, 0, 0; -1, -2, -1]; %horizontal edge
%H = [1,0,-1; 2, 0, -2; 1, 0, -1]; %vertical edge

%img_sobel = sobel_filter(img, H);
%figure, imshow(img_sobel);
%imwrite(img_sobel, 'sobel_h.jpg');
%imwrite(img_sobel, 'sobel_v.jpg');

%fprintf('Save sobel_h/v.jpg...\n');




%Gaussian filter
img = im2double(imread('lena.jpg'));
fprintf('lena.jpg...\n');

%hsize = 5; sigma = 2;
hsize = 9; sigma = 4;

img_gaussian = gaussian_filter(img, hsize, sigma);
figure, imshow(img_gaussian);
%imwrite(img_gaussian, 'gaussian_5.jpg');
imwrite(img_gaussian, 'gaussian_9.jpg');

fprintf('Save gaussian_5/9.jpg...\n');


