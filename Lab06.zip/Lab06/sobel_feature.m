function [magnitude, orientation] = sobel_feature(img)

    %horizontal edge
    Hy = [1, 2, 1; 0, 0, 0; -1, -2 -1];
    
    %vertical edge
    Hx = [1, 0, -1; 2, 0, -2; 1, 0, -1];
    
    %Sobel filtering
    grad_y = imfilter(img, Hy);
    grad_x = imfilter(img, Hx);
    
    
    %compute gradient magnitude and orientation
    magnitude = sqrt(grad_y.^2 + grad_x.^2);
    orientation = atan2(grad_y, grad_x);
end