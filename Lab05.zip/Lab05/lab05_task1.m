img = im2double(imread('lena.jpg'));

sigma = 2.0;
hsize = 7;
scale = 5;

I = img;
A = img;

% Gaussian Pyramid
for s = 1 : scale
    
    %Gaussian filter
    
    kernel  = fspecial('gaussian', hsize, sigma);
    
    for shift_u = 1 : size(I, 2)
        for shift_v = 1 : size(I, 1)
            
            x1 = shift_u - floor(hsize/2);
            x2 = shift_u + floor(hsize/2);
            
            y1 = shift_v - floor(hsize/2);
            y2 = shift_v + floor(hsize/2);
            
            if((x1 > 1) && (x2 < (size(I, 2) - floor(hsize/2))) && (y1 >1) && (y2 < (size(I, 1) - floor(hsize/2))))
                
                patch = I(y1:y2, x1:x2);
                value = patch .* kernel;
                
                value = value(:);
                value = sum(value);
            else
                
                value = I(shift_v, shift_u);
                
            end
                
            I(shift_v, shift_u) = value;  
            
        end
    end
    
    %Save or show image
    imwrite(I, sprintf('Gaussian_scaled%d.jpg', s));
    figure, imshow(I);
   
    
    %Down-sampling
    I = imresize(I, 1/2);
    
end



% Laplacian Pyramid
for s = 1 : scale
    
    %Gaussian filtering
    
    kernel  = fspecial('gaussian', hsize, sigma);
    for shift_u = 1 : size(I, 2)
        for shift_v = 1 : size(I, 1)
            
            x1 = shift_u - floor(hsize/2);
            x2 = shift_u + floor(hsize/2);
            
            y1 = shift_v - floor(hsize/2);
            y2 = shift_v + floor(hsize/2);
            
            if((x1 > 1) && (x2 < (size(I, 2) - floor(hsize/2))) && (y1 >1) && (y2 < (size(I, 1) - floor(hsize/2))))
                
                patch = I(y1:y2, x1:x2);
                value = patch .* kernel;
                
                value = value(:);
                value = sum(value);
            else
                
                value = I(shift_v, shift_u);
                
            end
                
            I(shift_v, shift_u) = value;  
            
        end
    end
    
    %Laplacian filtering
    
    I = A - I;
    
    %Save or show image
    imwrite(I + 0.5, sprintf('Laplacian_scale%d.jpg', s));
    
    %Down-sampling
    
    I = A;
    I = imresize(I, 1/2);
    A = imresize(A, 1/2);
    
end
